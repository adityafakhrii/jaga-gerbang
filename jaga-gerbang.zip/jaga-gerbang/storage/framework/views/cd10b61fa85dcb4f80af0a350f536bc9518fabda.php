<?php $__env->startSection('content'); ?>
	  <div id="login-page">
    <div class="container">
      <form class="form-login" action="/postlogin" method="POST">
        <?php echo e(csrf_field()); ?>

        <h2 class="form-login-heading">
          <p class="logo-login">
            <img src="<?php echo e(asset('asset/img/favicon.png')); ?>" style="width: 45px; margin-top: -3px;" alt="Jaga Gerbang.jpg">
            <b>JAGA <span>GERBANG</span></b>
          </p>
        </h2>
        <div class="login-wrap">
          <input name="username" type="text" class="form-control" placeholder="User ID" autofocus autocomplete="off" required>
          <br>
          <input name="password" type="password" class="form-control" placeholder="Password" required>
           <br>
          <button class="btn btn-theme05 btn-block" href="index.html" type="submit">
            <i class="fa fa-lock"></i> 
             Masuk
          </button>
          <hr>
          <div class="login-social-link centered">
                  <?php if(Session::has('fail')): ?>
                    <span class="helper-text" style="color:red;">
                      <p><i class="fa fa-times"></i>  Login Gagal !
                        <span>Username atau Password salah...</span>
                      </p>
                    </span>
                  <?php endif; ?>
          </div>
          <div class="registration">
            Lupa password ?<br/>
            <p class="" href="#">
              Silahkan hubungi Admin / Sekretaris OSIS 
              </p>
              <a href="/">Kembali ke Home</a>
          </div>
        </div>
      </form>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('auths.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaga-gerbang\resources\views/auths/login.blade.php ENDPATH**/ ?>