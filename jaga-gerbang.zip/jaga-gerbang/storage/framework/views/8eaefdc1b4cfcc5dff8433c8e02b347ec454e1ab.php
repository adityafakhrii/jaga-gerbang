<footer class="site-footer">
      <div class="text-center">
        <p>
          © Copyrights <strong>Dashio</strong>. All Rights Reserved
        </p>
        <div class="credits">
          Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
        </div>
        <a href="index.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer><?php /**PATH C:\xampp\htdocs\jaga-gerbang\resources\views/osis/layouts/includes/_footer.blade.php ENDPATH**/ ?>