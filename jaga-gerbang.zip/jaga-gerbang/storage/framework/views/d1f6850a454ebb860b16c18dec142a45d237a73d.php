    <title>Siswa Telat | Jaga Gerbang</title>
<?php $__env->startSection('content'); ?>

<style type="text/css">
  @media  only screen and (max-width: 800px){
    table{
      font-size: 10px;
    }
    .form-group{
      width: 99%;
    }
    .form-control{
      margin-top: 10px;
    }
    .btn-theme04{
      margin-top: -10px;
    }
  }
</style>

<section id="main-content">
    <section class="wrapper site-min-height">
        <div class="row mt">
          <div class="col-lg-12 mt">

            <div class="content-panel">

                <div class="row mt">
                  <div class="col-lg-12">
                    <h4 class="mb"><i class="fa fa-edit"></i> Edit Siswa Telat</h4>
                    <form action="/siswa-telat/<?php echo e($data_siswa_telat->id); ?>/update" method="POST" class="form-inline" role="form" style="margin-left: 1%;">
                      <?php echo e(csrf_field()); ?>

                      <div class="form-group ">
                        <label class="sr-only" for="exampleInputEmail2">Nama Siswa</label>
                        <input type="text" class="form-control" id="exampleInputEmail2" name="nama_siswa" value="<?php echo e($data_siswa_telat->nama_siswa); ?>">
                        <select name="kelas_id" type="text" class="form-control" style="cursor: pointer;">
                          <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($kls->id); ?>"><?php echo e($kls->nama_kelas); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </select>
                      </div>
                      
                      <button type="submit" class="btn btn-theme">Submit</button>
                    </form>
                  </div>
                </div> 


            </div>
          </div>
        </div>
    </section>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaga-gerbang\resources\views/osis/edit_siswa_telat.blade.php ENDPATH**/ ?>