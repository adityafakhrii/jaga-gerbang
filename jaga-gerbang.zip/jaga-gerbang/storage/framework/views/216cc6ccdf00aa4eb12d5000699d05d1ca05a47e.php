<aside>
      <div id="sidebar" class="nav-collapse " tabindex="5000" style="overflow: hidden; outline: none;">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion" style="display: block;">
          <p class="centered"><a href="profile.html"><img src="<?php echo e(asset('asset/img/ui-sam.jpg')); ?>" class="img-circle" width="80"></a></p>
          <h5 class="centered"><?php echo e(auth()->user()->name); ?></h5>
          <li class="mt">
            <a class="" href="/admin">
              <i class="fa fa-dashboard"></i>
              <span>Dashboard</span>
              </a>
          </li>
          <li class="sub-menu dcjq-parent-li">
            <a href="/data-seksi" class="dcjq-parent">
              <i class="fa fa-users"></i>
              <span>Data Seksi OSIS</span>
              <span class="dcjq-icon"></span></a>
          </li>
          <li class="sub-menu dcjq-parent-li">
            <a href="javascript:;" class="dcjq-parent">
              <i class="fa fa-home"></i>
              <span>Data Kelas</span>
              <span class="dcjq-icon"></span></a>
            <ul class="sub" style="display: none;">
              <li><a href="general.html">Lihat Data</a></li>
              <li><a href="buttons.html">Tambah Data</a></li>
            </ul>
          </li>
        </ul>
        <!-- sidebar menu end-->
      </div>
    </aside><?php /**PATH C:\xampp\htdocs\jaga-gerbang\resources\views/admin/layouts/includes/_sidebar.blade.php ENDPATH**/ ?>