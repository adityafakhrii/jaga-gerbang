    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right"></div>
      </div>
      <!--logo start-->
      <a href="/" class="logo">
        <img src="<?php echo e(asset('asset/img/favicon.png')); ?>" style="width: 40px; margin-top: -3px;" alt="Jaga Gerbang.jpg">
        <b>JAGA <span>GERBANG</span></b>
      </a>
      <!--logo end-->
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
              
        </ul>
      </div>
    </header><?php /**PATH C:\xampp\htdocs\jaga-gerbang\resources\views/dashboard/layouts/includes/_header.blade.php ENDPATH**/ ?>