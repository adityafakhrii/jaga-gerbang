    <title>Dashboard OSIS | Jaga Gerbang</title>

<?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('osis.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaga-gerbang\resources\views/osis/index.blade.php ENDPATH**/ ?>