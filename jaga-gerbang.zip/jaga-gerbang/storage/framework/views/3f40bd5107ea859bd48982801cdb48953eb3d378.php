    <title>Tambah Seksi OSIS | Jaga Gerbang</title>

<?php $__env->startSection('content'); ?>
  <section id="main-content">
      <section class="wrapper">
        <h3><i class="fa fa-plus"></i>  Tambah Data Seksi</h3>
        <div class="row mt">
          <div class="col-lg-12">
           
            <div class="form-panel">
              <div class="form">
                <form class="cmxform form-horizontal style-form" id="signupForm" method="POST" action="/data-seksi/create">
                  <div class="form-group ">
                    <label for="nama_seksi" class="control-label col-lg-2">Nama Seksi</label>
                    <div class="col-lg-10">
                      <input class=" form-control" id="nama_seksi" name="nama_seksi" type="text">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="jumlah_anggota" class="control-label col-lg-2">Jumlah Anggota</label>
                    <div class="col-lg-10">
                      <input class=" form-control" id="jumlah_anggota" name="jumlah_anggota" type="text">
                    </div>
                  </div>
                  <div class="form-group ">
                    <label for="bidang" class="control-label col-lg-2">Bidang</label>
                    <div class="col-lg-10">
                      <input class="form-control " id="bidang" name="bidang" type="text">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-lg-offset-2 col-lg-10">
                      <button class="btn btn-theme" type="submit">Simpan</button>
                      <a href="/data-seksi" class="btn btn-theme04" type="button">Kembali</a>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>
      </section>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaga-gerbang\resources\views/admin/tambah_seksi.blade.php ENDPATH**/ ?>