<title>Jaga Gerbang</title>
<?php $__env->startSection('content'); ?>

<style>
  @media  only screen and (max-width: 800px){
    table{
      font-size: 9px;
    }
    h4{
      font-size: 14px;
    }
    ul.top-menu > li > .btn-home{
      font-size: 13px;
    }
  }
</style>

<div id="login-page">
    <header class="header">
      
      <a href="/dashboard" class="logo">
        <img src="<?php echo e(asset('asset/img/favicon.png')); ?>" style="width: 40px; margin-top: -3px;" alt="Jaga Gerbang.jpg">
        <b>JAGA <span>GERBANG</span></b>
      </a>
      
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
          <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                       <li><a class="btn-home" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a></li> 
                       <?php else: ?>
                       <li> <a class="btn-home" href="<?php echo e(route('login')); ?>">Login</a></li>
                    <?php endif; ?>
            <?php endif; ?>
        </ul>
      </div>
    </header>
    <div class="container" >
            <section class="wrapper site-min-height">
                <div class="row mt">
                    <div class="col-lg-12 ">
                        <div class="content-panel" style="border-radius: 5px;margin-top: 1%;">
                            <center>
                                <div class=" col-sm-12" >
                                    <h4> 
                                        <i class="fa fa-users"> </i> Data Siswa Telat Hari ini
                                    </h4>
                                    <form class="navbar-form navbar-left" action ="/" method="GET">
                                      <div class="input-group">
                                        <input name="search" type="text" class="form-control" placeholder="Cari disini...">
                                        <span class="input-group-btn"><button type="submit" class="btn btn-primary">Go</button></span>
                                      </div>
                                    </form>
                                    <br>
                                </div>
                            </center>
                            
                            <section class="unseen">
                              <table class="table table-bordered table-striped table-condensed" >
                                <thead>
                                  <tr>
                                      <th class="numeric" style="text-align: center;">No</th>
                                      <th class="numeric" style="text-align: center;">Nama Siswa</th>
                                      <th class="numeric" style="text-align: center;">Kelas</th>
                                      <th class="numeric" style="text-align: center;">Pukul Telat</th>
                                      <th class="numeric" style="text-align: center; ">Batas Sanksi</th>
                                      <th class="numeric" style="text-align: center;">Ket. Sanksi</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <?php $no=1; ?>
                                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                      <td style="text-align: center;"><?php echo e($no++); ?></td>
                                      <td><?php echo e($row->nama); ?></td>
                                      <td style="text-align: center;"><?php echo e($row->nama_kelas); ?></td>
                                      <td style="text-align: center;"><?php echo e($row->pukul_telat); ?> WIB</td>
                                      <td style="text-align: center;"><?php echo e($row->batas_waktu_sanksi); ?> WIB</td>
                                      <td style="text-align: center;"><?php echo e($row->ket_sanksi); ?> </td>
                                  </tr>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                              </table>
                          <center><?php echo e($data->links()); ?></center>

                            </section>
                            
                        </div>
                    </div>
                </div>
            </section>
    </div>
</div>



<footer class="site-footer" style="background: transparent;" >
      <div class="text-center">
        <p>
          © Copyright <strong>Aditya Fakhri Riansyah</strong>. All Rights Reserved
        </p>
        <div class="credits">
          Created with <i class="fa fa-heart" aria-hidden="true"></i> and template by <a style="color: #fff;font-weight: bold;" href="https://templatemag.com/">TemplateMag</a>
        </div>
        
      </div>
    </footer>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auths.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaga-gerbang\resources\views/welcome.blade.php ENDPATH**/ ?>