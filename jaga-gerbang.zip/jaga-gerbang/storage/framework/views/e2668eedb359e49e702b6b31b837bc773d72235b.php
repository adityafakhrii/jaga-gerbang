    <title>Edit Kelas | Jaga Gerbang</title>

<?php $__env->startSection('content'); ?>
<section id="main-content">
      <section class="wrapper site-min-height">
        <div class="row mt">
          <div class="col-lg-12">
          	
            <h4><i class="fa fa-edit"></i>  Edit Kelas</h4>
            <div class="form-panel">
				                <form class="cmxform form-horizontal style-form" id="signupForm" method="POST" action="/data-kelas/<?php echo e($data_kelas->id); ?>/update">
				                  <?php echo e(csrf_field()); ?>

				                  <div class="form-group ">
				                    <label for="nama_kelas" class="control-label col-lg-2">Nama Kelas</label>
				                    <div class="col-lg-10">
				                      <input class=" form-control" id="nama_kelas" name="nama_kelas" type="text" value="<?php echo e($data_kelas->nama_kelas); ?>">
				                    </div>
				                  </div>
				                      <a href="/data-kelas" class="btn btn-warning">Batal</a>
				                      <button type="submit" class="btn btn-primary">Simpan</button>
	                    		</form>
            </div>
            <!-- /form-panel -->
          </div>
          <!-- /col-lg-12 -->
        </div>

      </section>
</section>






							
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jaga-gerbang\resources\views/admin/edit_kelas.blade.php ENDPATH**/ ?>