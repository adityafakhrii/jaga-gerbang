    <header class="header black-bg">
      <div class="sidebar-toggle-box">
        <div class="fa fa-bars tooltips" data-placement="right"></div>
      </div>
      <!--logo start-->
      <a href="/" class="logo">
        <img src="{{asset('asset/img/favicon.png')}}" style="width: 40px; margin-top: -3px;" alt="Jaga Gerbang.jpg">
        <b>JAGA <span>GERBANG</span></b>
      </a>
      <!--logo end-->
      <div class="top-menu">
        <ul class="nav pull-right top-menu">
              {{-- <li>
                <input style="background-color: white;color: grey;" type="text" name="search" id="search" class="logout col-sm-2" placeholder="Cari data disini..."/>
              </li>   --}}
        </ul>
      </div>
    </header>